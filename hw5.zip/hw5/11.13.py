import basic_problem as bp
import graph as g

if __name__ == '__main__':
    m, n = 4, 5
    V, E = g.mn_graph(m, n)
    V, E = g.weighted_graph(V, E, 10)
    print("V: " + str(V) + "\nE: " + str(E))
    d, di, do = bp.degree_set_w(V, E)
    Pc, Hx, Hy = bp.cratical_path(V, E, di, do, 0, m * n - 1)
    print("The key path from 0 to (n * m - 1) is: " + str(Pc))