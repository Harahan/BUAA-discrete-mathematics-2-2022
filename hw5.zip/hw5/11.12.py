import basic_problem as bp
import graph as g

if __name__ == '__main__':
    m, n = 4, 5
    V, E = g.mn_graph(m, n)
    V, E = g.weighted_graph(V, E, 10)
    print("V: " + str(V) + "\nE: " + str(E))
    Hx, Pm = bp.shortest_path(V, E, 0, n * m - 1)
    print("The shortest path from 0 to (n * m - 1) is :" +
          str(sorted(Pm)[0][1:]) + "\nThe length of the way is: " + str(sorted(Pm)[0][0]))
