import numpy as np


SYSTEM = -1
p = -1
N = -1


def create_klein():
	G = set({'e', 'a', 'b', 'c'})
	return G


def mul_klein(a, b):
	G = ['e', 'a', 'b', 'c']
	km = np.array([['e', 'a', 'b', 'c'], ['a', 'e', 'c', 'b'], ['b', 'c', 'e', 'a'], ['c', 'b', 'a', 'e']])
	i, j = G.index(a), G.index(b)
	c = km[i, j]
	return c


def inv_klein(a):
	"""inverse element"""
	return a


def e_klein():
	"""identity element"""
	return 'e'


def is_sociative_law(G):
	tv = True
	for a in G:
		for b in G:
			for c in G:
				f0 = mul(mul(a, b), c)
				f1 = mul(a, mul(b, c))
				tv = tv & (f0 in G) & (f1 in G) & (f0 == f1)
	return tv


def is_identity(G):
	e = ide()
	tv = e in G
	for a in G:
		f0 = mul(e, a)
		tv = tv & (f0 == a)
	return tv


def is_inverse(G):
	e = ide()
	tv = True
	for a in G:
		f0 = mul(inv(a), a)
		tv = tv & (inv(a) in G) & (f0 == e)
	return tv


def is_commutation_law(G):
	tv = True
	for a in G:
		for b in G:
			tv = tv & mul(a, b) == mul(b, a)
	return tv


def is_group(G):
	e = ide()
	tv = e in G
	tv = tv & is_sociative_law(G) & is_identity(G) & is_inverse(G)
	return tv


def create_mod_n():
	G = set(range(N))
	return G


def mul_mod_n(a, b):
	c = (a + b) % N
	return c
	
	
def e_mod_n():
	return 0


def inv_mod_n(a):
	e = e_mod_n()
	H = range(N)
	for k in H:
		if (a + k) % N == e:
			break
	av = k
	return av


def create_mod_p():
	G = set(range(1, p))
	return G


def mul_Np(a, b):
	c = (a * b) % p
	return c


def e_Np():
	return 1


def inv_Np(a):
	e = e_Np()
	H = range(1, p)
	av = -1
	for k in H:
		if (a * k) % p == e:
			av = k
			break
	return av


def mul(a, b):
	# klein
	if SYSTEM == 1:
		c = mul_klein(a, b)
	# mod_n
	if SYSTEM == 2:
		c = mul_mod_n(a, b)
	# Np
	if SYSTEM == 3:
		c = mul_Np(a, b)
	return c


def ide():
	# klein
	if SYSTEM == 1:
		c = e_klein()
	# mod_n
	if SYSTEM == 2:
		c = e_mod_n()
	# Np
	if SYSTEM == 3:
		c = e_Np()
	return c


def inv(a):
	# klein
	if SYSTEM == 1:
		c = inv_klein(a)
	# mod_n
	if SYSTEM == 2:
		c = inv_mod_n(a)
	# Np
	if SYSTEM == 3:
		c = inv_Np(a)
	return c


def power_n(a):
	e = ide()
	n = 1
	b = a
	while b != e:
		b = mul(b, a)
		n += 1
	return n


def mul_set(A, B):
	C = set({})
	for a in A:
		for b in B:
			C = C | {mul(a, b)}
	return C


def inv_set(A):
	A_v = set({})
	for a in A:
		A_v = A_v | {inv(a)}
	return A_v

