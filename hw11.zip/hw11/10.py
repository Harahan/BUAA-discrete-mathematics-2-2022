import random

import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 3
	als.p = 13
	n1, n2, n3 = 8, 6, 10
	G = als.create_mod_p()
	print(als.is_group(G))
	A = set(random.sample(list(G), n1))
	B = set(random.sample(list(G), n2))
	C = set(random.sample(list(G), n3))
	# 1
	print('(1): ' + str(als.mul_set(A, B | C) == als.mul_set(A, B) | als.mul_set(A, C)))
	# 2
	print('(2): ' + str(als.inv_set(als.mul_set(A, B)) == als.mul_set(als.inv_set(B), als.inv_set(A))))
	