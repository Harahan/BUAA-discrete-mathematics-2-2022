import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 2
	als.N = 18
	G = als.create_mod_n()
	print(als.is_group(G))
	e = als.ide()
	# 1
	tv1 = True
	for a in G:
		a_inv = als.inv(a)
		if als.mul(a_inv, a) != e or als.mul(a, a_inv) != e:
			tv1 = False
			break
	print('(1): ' + str(tv1))
	# 2
	tv2 = True
	for a in G:
		if als.mul(e, a) != a or als.mul(a, e) != a:
			tv2 = False
			break
	print('(2): ' + str(tv2))
	# 3
	tv3 = True
	for a in G:
		a_inv = als.inv(a)
		for b in G:
			b_inv = als.inv(b)
			if als.inv(als.mul(a, b)) != als.mul(a_inv, b_inv):
				tv3 = False
				break
	print('(3): ' + str(tv3))
	