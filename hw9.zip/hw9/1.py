import graph as g
import basic_problem as bp

if __name__ == '__main__':
	V, E = g.mn_graph(10, 10)
	V, E = g.weighted_graph(V, E, 5000)
	Vt, Et = bp.prim_span_tree(V, E)
	print("Prim:\n" + str(Vt) + "\n" + str(Et))