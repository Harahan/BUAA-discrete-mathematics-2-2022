import algebraic_system as als


def divide(a, b):
	return a / b


if __name__ == "__main__":
	X = set({1, -1})
	res = True
	for i in X:
		for j in X:
			if divide(i, j) not in X:
				res = False
				break
	print("X/X->X is an algebraic operation: " + str(res))
	
	G = als.create_klein()
	res = True
	for i in G:
		for j in G:
			if als.mul_klein(i, j) not in G:
				res = False
				break
	print("Klein four group is an algebraic operation: " + str(res))
	
	