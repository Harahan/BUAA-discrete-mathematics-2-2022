import numpy as np


def create_klein():
	G = set({'e', 'a', 'b', 'c'})
	return G


def mul_klein(a, b):
	G = ['e', 'a', 'b', 'c']
	km = np.array([['e', 'a', 'b', 'c'], ['a', 'e', 'c', 'b'], ['b', 'c', 'e', 'a'], ['c', 'b', 'a', 'e']])
	i, j = G.index(a), G.index(b)
	c = km[i, j]
	return c


def inv_klein(a):
	"""inverse element"""
	return a


def e_klein():
	"""identity element"""
	return 'e'
