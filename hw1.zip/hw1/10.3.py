import random

import graph as g


def not_graph(m, n):
	global V, E
	V = random.sample(range(1, 101), m)
	V = set(V)
	E = set({})
	for i in range(n):
		u, v = random.randint(1, 100000), random.randint(1, 100000)
		E = E | {(u, v)}
	return [V, E]


if __name__ == "__main__":
	V, E = not_graph(10, 20)  # 非图
	print(g.is_graph(V, E))
