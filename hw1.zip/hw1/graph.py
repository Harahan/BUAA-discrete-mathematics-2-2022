import random


def is_graph(V, E):
	tv = True
	for (u, v) in E:
		tv = tv and (u in V) and (v in V)
	return tv


def cartesian_product(X, Y):
	"""生成两个集合的笛卡尔积"""
	XY = set({})
	for x in X:
		for y in Y:
			XY.add((x, y))
	return XY
	

def create_graph(m, n):
	"""m 个顶点无向图"""
	global V, XY
	V = range(m)
	XY = cartesian_product(V, V)
	E = random.sample(XY, n);
	E = set(E)
	for (u, v) in E:
		if (v, u) not in E:
			E = E | {(v, u)}
	V = set(V)
	return [V, E]


def create_digraph(m, n):
	"""m 个顶点的有向图"""
	global V, XY
	V = range(m)
	XY = cartesian_product(V, V)
	E = random.sample(XY, n)
	V = set(V)
	E = set(E)
	return [V, E]