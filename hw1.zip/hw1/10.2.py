import graph as g


if __name__ == '__main__':
    V, E = g.create_graph(10, 20)  # 无向图
    print(g.is_graph(V, E))
    V, E = g.create_digraph(10, 20)  # 有向图
    print(g.is_graph(V, E))
    
