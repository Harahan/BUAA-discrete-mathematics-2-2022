import graph as g


def sub_euler_circuit(E, v0):
	"""从一点出发，找到一条回路，返回顺序和使用的边"""
	circuit = tuple([v0])
	S = set({})
	while circuit[0] != circuit[-1] or len(circuit) == 1:
		y = circuit[-1]
		for (u, v) in E:
			if u == y:
				circuit = circuit + tuple([v])
				E = E - {(u, v)}
				S = S | {(u, v)}
				break
	return [circuit, S]


def set_2v(E):
	"""从边集产生点集"""
	V = set({})
	for (u, v) in E:
		V = V | {u, v}
	return V


def euler_circuit(E, v0):
	"""给出欧拉回路"""
	[circuit, S] = sub_euler_circuit(E, v0)
	E = E - S
	while E != set({}):
		V1 = set(circuit)
		V2 = set_2v(E)
		V1V2 = V1 & V2
		# 已有回路和整个图的公共点集
		for v0 in V1V2:
			# 从公共点集，生成回路点集和边
			[sub_circuit, S] = sub_euler_circuit(E, v0)
			if S == set({}):
				continue
			k = circuit.index(v0)
			circuit = circuit[0: k] + sub_circuit + circuit[k + 1: -1] + tuple([circuit[-1]])
			E = E - S
			break
	return circuit


def tour_path0(V, E, path, m):
	while len(path) < m:
		w = path[-1]
		i = V.index(w)
		E1 = E[i]
		E2 = E1[1]
		for u in E2:
			if u not in path:
				path.append(u)
				break
		if path[-1] == w:
			break
	return path


def tour_path1(V, E, path, m):
	v = path.pop()
	while len(path) != 0:
		u = path[-1]
		i = V.index(u)
		E1 = E[i]
		E2 = E1[1]
		k = E2.index(v)
		while k < len(E2) - 1:
			k += 1
			v = E2[k]
			if v not in path:
				path.append(v)
				break
		if u != path[-1]:
			break
		v = path.pop()
	return path


def tour_path(V, E, path, m):
	if len(path) == m:
		path = tour_path1(V, E, path, m)
	while len(path) != 0:
		path = tour_path0(V, E, path, m)
		if len(path) == m:
			break
		path = tour_path1(V, E, path, m)
	return path


def hamilton_path(V, E, v0):
	global Ea, paths
	V = sorted(V)
	Ea = g.adjacent_list(V, E)
	paths = set({})
	path = [v0]
	m = len(V)
	path = tour_path(V, Ea, path, m)
	paths = paths | {tuple(path)}
	k = 1
	while len(path) == m:
		if k >= 100:
			break # end
		path = tour_path(V, Ea, path, m)
		if len(path) == m:
			paths = paths | {tuple(path)}
			k += 1
	return paths
