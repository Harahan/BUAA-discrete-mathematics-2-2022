import random
import networkx as nx
import matplotlib.pyplot as plt


def is_graph(V, E):
	tv = True
	for (u, v) in E:
		tv = tv and (u in V) and (v in V)
	return tv


def cartesian_product(X, Y):
	"""生成两个集合的笛卡尔积"""
	XY = set({})
	for x in X:
		for y in Y:
			XY.add((x, y))
	return XY
	

def create_graph(m, n):
	"""m 个顶点无向图"""
	global V, XY
	V = range(m)
	XY = cartesian_product(V, V)
	E = random.sample(XY, n);
	E = set(E)
	for (u, v) in E:
		if (v, u) not in E:
			E = E | {(v, u)}
	V = set(V)
	return [V, E]


def create_digraph(m, n):
	"""m 个顶点的有向图"""
	global V, XY
	V = range(m)
	XY = cartesian_product(V, V)
	E = random.sample(XY, n)
	V = set(V)
	E = set(E)
	return [V, E]


def knight_tour_graph(n):
	"""骑士周游图"""
	p_8 = [[-1, -2], [-2, -1], [-2, 1], [-1, 2], [1, 2], [2, 1], [2, -1], [1, -2]]
	N = n * n
	V = list(range(N))
	E = set({})
	for k in range(N):
		j = k % n
		i = k // n
		for [u, v] in p_8:
			if 0 <= i + u < n and 0 <= j + v < n:
				E = E | {(k, (i + u) * n + (j + v))}
	return [V, E]
	

def draw_graph(E):
	G = nx.Graph()
	G.add_edges_from(E)
	nx.draw(G, node_size=200, node_color='r', with_labels=True, font_color='w')
	plt.show()
	return


def draw_digraph(E):
	G = nx.DiGraph()
	G.add_edges_from(E)
	nx.draw(G, node_size=200, node_color='r', with_labels=True, font_color='w')
	plt.show()
	return


def adjacent_list(V, E):
	"""邻接表"""
	Ea = []
	for w in V:
		e0 = [w]
		e1 = []
		for (u, v) in E:
			if u == w and v not in e1:
				e1 = e1 + [v]
			if v == w and u not in e1:
				e1 = e1 + [u]
		e0 = e0 + [sorted(e1)]
		Ea = Ea + [e0]
	return sorted(Ea)

