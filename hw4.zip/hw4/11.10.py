import basic_problem as bp
import graph as g


if __name__ == '__main__':
	[V, E] = g.knight_tour_graph(6)
	print("V: " + str(V) + "\nE: " + str(E))
	paths = bp.hamilton_path(V, E, V[0])
	k = 1
	for path in paths:
		print("Hamilton path" + str(k) + ": " + str(path))
		k += 1
	