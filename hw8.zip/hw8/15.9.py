import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 3
	P = [17, 19, 71, 97]
	for p in P:
		als.p = p
		G = als.create_mod_p(als.p)
		R = set({})
		for a in G:
			p = als.power_n(a)
			R = R | {(a, p)}
		print("MOD " + str(p) + "(Np) GROUP:\n" + str(G) + "\n" + str(sorted(R)) + "\n")
