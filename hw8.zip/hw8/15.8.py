import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 2
	N = [10, 25, 55, 75, 95]
	for n in N:
		als.N = n
		G = als.create_mod_n(als.N)
		R = set({})
		for a in G:
			p = als.power_n(a)
			R = R | {(a, p)}
		print("MOD " + str(n) + " GROUP:\n" + str(G) + "\n" + str(sorted(R)) + "\n")
