import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 5
	als.N = 5
	print(als.create_permutation_group())
	