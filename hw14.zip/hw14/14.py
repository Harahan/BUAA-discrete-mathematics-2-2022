import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 3
	als.p = 31
	G = als.create_mod_p()
	H = {1, 2, 4, 8, 16}
	print(als.is_sub_group(G, H))
	