import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 5
	als.N = 5
	G = als.create_permutation_group()
	print(als.sub_group(G))
	