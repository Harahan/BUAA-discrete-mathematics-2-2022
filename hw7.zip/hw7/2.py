import basic_problem as bp
import graph as g

if __name__ == '__main__':
	file = open('test.txt', 'r')
	tot = []
	for line in file:
		tot += line.replace(' ', '').replace('\n', '')
	W = g.frequency_list(tot)
	print("The frequency of every char:\n" + str(W))
	tree = g.huffman_tree(W)
	C = bp.huffman_coding(tree)
	print("Huffman code:\n" + str(C))
	r0, r = bp.coding_entropy(W, C)
	print("The entropy:\n" + str(r0))
	print("The average length:\n" + str(r))
