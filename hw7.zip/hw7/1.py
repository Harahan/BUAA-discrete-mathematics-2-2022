import random

import basic_problem as bp

import graph as g


if __name__ == '__main__':
	nodes = [random.randint(1, 1000) for i in range(20)]
	tree = g.binary_tree(nodes)
	print("Binary Tree:\n" + str(tree))
	print("Preorder Traval:\n" + str(bp.preorder_traversal(tree)))
	print("Inorder Traval:\n" + str(bp.inorder_traversal(tree)))
	print("Postorder Traval:\n" + str(bp.postorder_traversal(tree)))
	