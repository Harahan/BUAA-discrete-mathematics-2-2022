import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 4
	als.N = 10
	als.Cn = 2
	print(str(als.create_cyclic_group()))