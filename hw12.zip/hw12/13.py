import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 2
	als.N = 27
	G = als.create_mod_n()
	H = {0, 3, 6, 9, 12, 15, 18, 21, 24}
	print(als.is_sub_group(G, H))
	