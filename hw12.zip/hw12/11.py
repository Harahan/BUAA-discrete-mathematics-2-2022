import algebraic_system as als

if __name__ == '__main__':
	als.SYSTEM = 2
	als.N = 54
	G = als.create_mod_n()
	print(str(als.sub_group(G)))
	