import algebraic_system as als

if __name__ == '__main__':
	als.Cn = 2
	als.N = 20
	als.SYSTEM = 4
	G = als.create_cyclic_group()
	print(als.sub_group(G))
	