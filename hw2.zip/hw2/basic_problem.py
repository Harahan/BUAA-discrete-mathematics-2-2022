def sub_euler_circuit(E, v0):
	"""从一点出发，找到一条回路，返回顺序和使用的边"""
	circuit = tuple([v0])
	S = set({})
	while circuit[0] != circuit[-1] or len(circuit) == 1:
		y = circuit[-1]
		for (u, v) in E:
			if u == y:
				circuit = circuit + tuple([v])
				E = E - {(u, v)}
				S = S | {(u, v)}
				break
	return [circuit, S]


def set_2v(E):
	"""从边集产生点集"""
	V = set({})
	for (u, v) in E:
		V = V | {u, v}
	return V


def euler_circuit(E, v0):
	"""给出欧拉回路"""
	[circuit, S] = sub_euler_circuit(E, v0)
	E = E - S
	while E != set({}):
		V1 = set(circuit)
		V2 = set_2v(E)
		V1V2 = V1 & V2
		# 已有回路和整个图的公共点集
		for v0 in V1V2:
			# 从公共点集，生成回路点集和边
			[sub_circuit, S] = sub_euler_circuit(E, v0)
			if S == set({}):
				continue
			k = circuit.index(v0)
			circuit = circuit[0: k] + sub_circuit + circuit[k + 1: -1] + tuple([circuit[-1]])
			E = E - S
			break
	return circuit
