import basic_problem as bp
import graph as g


if __name__ == "__main__":
	[V, E] = g.knight_tour_graph(10)
	print(bp.euler_circuit(E, 1))