import graph as g

if __name__ == '__main__':
	V0, V1, E1 = g.complete_bigraph_set(5, 5)
	V2, E2 = g.complete_graph_set(7)
	V1 = V0 | V1
	print(len(E2) <= 2 * len(V2) - 4)
	print(len(E1) <= 2 * len(V1) - 4)

	