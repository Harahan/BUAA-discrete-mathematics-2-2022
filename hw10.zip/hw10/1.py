import basic_problem as bp
import graph as g

if __name__ == '__main__':
	Vx, Vy, E = g.complete_bigraph_set(10, 15)
	print('Vx: ' + str(Vx) + '\nVy: ' + str(Vy) + '\nE: ' + str(E))
	path = ['x0', 'y0']
	match_set = bp.match_max_set(Vx, Vy, E, path)
	print('match_set: ' + str(match_set))