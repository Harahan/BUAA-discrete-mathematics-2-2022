import algebraic_system as als


if __name__ == '__main__':
	G = set({i for i in range(1, 19)})
	tv = False
	als.SYSTEM = 3
	for i in range(1, 100):
		als.p = 19
		if als.is_group(G):
			tv = True
			break
	if tv:
		print("G is a group and Np = " + str(als.p))
	else:
		print("G is not a group")