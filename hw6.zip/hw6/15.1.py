import algebraic_system as als


if __name__ == '__main__':
    N = set({10, 25, 55, 75, 95})
    for i in N:
        print("N = " + str(i) + "\n" + str(als.create_mod_n(i)))