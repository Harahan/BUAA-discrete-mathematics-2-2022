import algebraic_system as als


if __name__ == '__main__':
    Np = set({17, 19, 71, 97})
    for i in Np:
        print("N = " + str(i) + "\n" + str(als.create_mod_p(i)))